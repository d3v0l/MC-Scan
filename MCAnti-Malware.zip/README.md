MC-Scan is an inspector that inspects Minecraft plugins and searches for backdoors.

require("./server")
require("./web")